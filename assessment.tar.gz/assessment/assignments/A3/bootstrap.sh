#!/bin/sh
export FLASK_APP=./A3/index.py
flask --debug run -h 0.0.0.0
